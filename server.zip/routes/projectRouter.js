// import { Router } from 'express'
// import express from 'express';

// import auth from '../middleware/auth.js';
// import { createProject } from '../controllers/project.js';


// const projectRouter = Router();
// projectRouter.post('/', auth, createProject);
// export default projectRouter