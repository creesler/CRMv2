const userPermissions = {
    listUsers:{
        roles:['admin', 'editor']
    },
    updateStatus:{
        roles:['admin']
    },
}

export default userPermissions